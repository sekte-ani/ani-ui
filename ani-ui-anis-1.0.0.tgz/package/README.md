# ANI UI (`@ani-ui/anis`)

Tailwind v4-based React design system library (shadcn-style components + hooks).

## Requirements

- `react` `^18 || ^19`
- `react-dom` `^18 || ^19`
- `tailwindcss` `^4`

## Install

```bash
npm install @ani-ui/anis
```

## Consumer Setup

1. Import library styles in your global stylesheet:

```css
@import "tailwindcss";
@import "@ani-ui/anis/styles.css";

/* Adjust the relative path based on your project structure */
@source "../node_modules/@ani-ui/anis/dist/**/*.js";
```

2. Use components:

```tsx
import { Button, Dialog, DialogContent, DialogTrigger } from "@ani-ui/anis"
```

## Next.js (App Router)

Interactive components and hooks should be imported from the client entry:

```tsx
"use client"

import { Button, useIsMobile } from "@ani-ui/anis/client"
```

You can still import SSR-safe exports from `@ani-ui/anis`, but `@ani-ui/anis/client` is the safe default in Next client components.

## Laravel + Inertia (React)

When using the Vite stack, add the same global CSS imports and `@source` line in your app stylesheet, then import components from `@ani-ui/anis`.

## Build This Library

```bash
npm run build
```

Output is generated in `dist/`:

- ESM modules (`.js`)
- Type declarations (`.d.ts`)
- Theme/styles entry (`styles.css`)
